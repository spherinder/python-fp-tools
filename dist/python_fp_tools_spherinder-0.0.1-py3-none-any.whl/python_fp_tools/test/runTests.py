# --------------------------------------------------------
# (c) Copyright 2014 by Jason DeLaat. 
# Licensed under BSD 3-clause licence.
# --------------------------------------------------------

import unittest

from test_Reader import *
from test_Maybe import *
from test_Either import *
from test_List import *
from test_Monoid import *
from test_Writer import *
from test_State import *

unittest.main()
