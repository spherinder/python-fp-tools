from abc import ABCMeta, abstractmethod


class Container:

    def __init__(self, value):
        self.value = value

    def getValue(self):
        return self.value

    def __eq__(self, other):
        return self.value == other.value


class Functor(Container, metaclass=ABCMeta):

    def __init__(self, value):
        super().__init__(value)

    @abstractmethod
    def map(self, f):
        pass


class Applicative(Functor, metaclass=ABCMeta):

    def __init__(self, function):
        super().__init__(function)

    @abstractmethod
    def amap(self, functorValue):
        pass

    @classmethod
    @abstractmethod
    def of(value):
        pass


class Monad(Applicative, metaclass=ABCMeta):

    def __init__(self, value):
        # print("Monad", value)
        super().__init__(value)

    @abstractmethod
    def bind(self, function):
        pass

    def __rshift__(self, function):
        result = self.bind(function)
        if not isinstance(result, Monad):
            raise TypeError("Operator '>>' must return a Monad instance.")
        return result




class Foldable(Monoid, metaclass=ABCMeta):

    def __init__(self, value):
        super().__init__(value)

    @abstractmethod
    def foldl(self, function):
        pass


class Traversable(Applicative, Foldable, metaclass=ABCMeta):

    def __init__(self, value):
        # print("Trav", value)
        super().__init__(value)

    @abstractmethod
    def sequence(self):
        pass
