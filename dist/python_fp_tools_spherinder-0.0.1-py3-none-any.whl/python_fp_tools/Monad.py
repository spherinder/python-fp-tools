from Applicative import Applicative


class Monad(Applicative):


    def __init__(self, value):
        super(Monad, self).__init__(value)

    def bind(self, function):
        raise NotImplementedError

    def __rshift__(self, function):

        if callable(function): 
            result = self.bind(function)
            if not isinstance(result, Monad): raise TypeError("Operator '>>' must return a Monad instance.")
            return result
        else:
            if not isinstance(function, Monad): raise TypeError("Operator '>>' must return a Monad instance.")
            return self.bind(lambda _: function)
