from Container import Container
from abc import abstractmethod, ABCMeta


class Semigroup(Container, metaclass=ABCMeta):

    def __init__(self, value):
        super().__init__(value)

    @abstractmethod
    def plus(self, other):
        pass

    def __add__(self, other):
        result = self.plus(other)
        if not isinstance(result, Semigroup):
            raise TypeError("Operator '+' must return a Semigroup instance.")


class Monoid(Semigroup, metaclass=ABCMeta):

    def __init__(self, value):
        super().__init__(value)

    @staticmethod
    @abstractmethod
    def zero():
        pass
