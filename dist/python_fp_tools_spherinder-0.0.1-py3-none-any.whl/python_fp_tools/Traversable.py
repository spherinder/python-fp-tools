from abc import abstractmethod, ABCMeta
from Monoid import Monoid
from Applicative import Applicative

class Foldable(Monoid, metaclass=ABCMeta):
    def __init__(self, value):
        super().__init__(value)

    @abstractmethod
    def foldl(self, function):
        pass


class Traversable(Applicative, Foldable, metaclass=ABCMeta):

    def __init__(self, value):
        # print("Trav", value)
        super().__init__(value)

    @abstractmethod
    def sequence(self):
        pass
