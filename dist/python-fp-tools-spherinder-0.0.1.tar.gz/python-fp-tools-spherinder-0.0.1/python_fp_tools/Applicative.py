from Functor import Functor


class Applicative(Functor):

    def __init__(self, function):
        super(Applicative, self).__init__(function)

    def amap(self, functorValue):
        raise NotImplementedError

    def __and__(self, functorValue):
        return self.amap(functorValue)
