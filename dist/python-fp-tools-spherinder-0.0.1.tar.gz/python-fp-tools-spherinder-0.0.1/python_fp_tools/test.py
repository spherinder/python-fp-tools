from collections import namedtuple
from python_fp_tools import *
from functools import reduce


a = List(2,3,4)
b = List(9,7,5)
c = List(a, b)
print(c.sequence())
