from Monad import *
from Monoid import *
from Traversable import Traversable
from functools import reduce


class List(list, Monad, Traversable):

    def __init__(self, *values):
        super(List, self).__init__(values)

    def __eq__(self, other):
        if not isinstance(other, List):
            raise TypeError("Can't compare List with non-List type.")
        return super(List, self).__eq__(other)

    def __ne__(self, other):
        if not isinstance(other, List):
            return True
        return super(List, self).__ne__(other)

    def __getslice__(self, start, end):
        return self.__getitem__(slice(start, end))

    def __getitem__(self, key):
        if isinstance(key, slice):
            return List(*super(List, self).__getitem__(key))
        return super(List, self).__getitem__(key)

    def __str__(self):
        display = "["
        for item in self:
            display += str(item) + ", "
        return display[:-2] + "]"

    @classmethod
    def unit(cls, value):
        return List(value)

    def getValue(self):
        return self

    def map(self, function):
        return List(*list(map(function, self)))

    def amap(self, functorValue):
        result = []
        for func in self.getValue():
            result.extend(func * functorValue)
        return List(*result)

    def bind(self, function):
        result = []
        for subList in (map(function, self)):
            result.extend(subList)
        return List(*result)

    def __rmul__(self, function):
        return self.map(function)

    @staticmethod
    def mzero():
        return List()

    def mplus(self, other):
        return List(*(super(List, self).__add__(other)))

    def __add__(self, other):
        return self.mplus(other)

    def foldl(self, function, unit):
        return List(*reduce(function, self.getValue(), unit))

    def sequence(self):
        def liftedCons(start, x):
            return x.map(lambda a: lambda b: b + [a]).amap(start)
        return reduce(liftedCons, self, self[0].unit([]))

a = List(1,2,3)
b = List(5,6,7)
c = List(a,b)
d = c.sequence()
print(d)
