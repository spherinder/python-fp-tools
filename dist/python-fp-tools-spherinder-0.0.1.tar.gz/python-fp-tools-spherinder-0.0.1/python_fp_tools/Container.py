class Container(object):

    def __init__(self, value):
        self.value = value

    def getValue(self):
        return self.value

    def __eq__(self, other):
        return self.value == other.value
