from Container import Container


class Functor(Container):

    def __init__(self, value):
        super(Functor, self).__init__(value)

    def map(self, function):
        raise NotImplementedError("'map' not defined.")

    def __rmul__(self, aFunction):
        return self.map(aFunction)

    @classmethod
    def unit(cls, value):
        raise NotImplementedError
